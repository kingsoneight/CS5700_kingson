/**************************************************************
 * spock.h
 *
 * Common header file for the SPOCK game.
 * Defines constants, includes standard libraries, and
 * declares functions and data structures shared by both
 * the server and client.
 *
 **************************************************************/

 #ifndef SPOCK_H
 #define SPOCK_H
 
 /* Standard Libraries */
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <unistd.h>
 #include <errno.h>
 #include <ctype.h>
 #include <arpa/inet.h>
 #include <sys/socket.h>
 #include <sys/types.h>
 #include <netinet/in.h>
 #include <fcntl.h>  // For fcntl() and O_NONBLOCK
 
 /* Defines */
 #define DEFAULT_PORT 5000
 #define BUFFER_SIZE 256
 #define MAX_NAME_LEN 32
 
 /* ANSI Color Macros */
 #define ANSI_RESET  "\x1b[0m"
 #define ANSI_BOLD   "\x1b[1m"
 #define ANSI_RED    "\x1b[31m"
 #define ANSI_GREEN  "\x1b[32m"
 #define ANSI_YELLOW "\x1b[33m"
 #define ANSI_BLUE   "\x1b[34m"
 #define ANSI_CYAN   "\x1b[36m"
 
 /* Enum: Game Moves */
 typedef enum {
     MOVE_INVALID = -1,
     MOVE_ROCK,
     MOVE_PAPER,
     MOVE_SCISSORS,
     MOVE_LIZARD,
     MOVE_SPOCK
 } Move;
 
 /* Enum: Message Types for Network Communication */
 typedef enum {
     MSG_MOVE,       /* Player move command (R/P/S/L/K) */
     MSG_SCORE,      /* Request to show score (M) */
     MSG_RESET,      /* Request to reset score (T) */
     MSG_QUIT,       /* Request to quit the game (Q) */
     MSG_RESULT,     /* Server sends round result + updated score */
     MSG_UPDATE,     /* (Not used in this code) */
     MSG_READY,      /* Server indicates it's ready for client's move */
     MSG_UNKNOWN     /* Unknown message type */
 } MsgType;
 
 /* Function Prototypes */
 int runServer(int port);
 int runClient(const char *server_ip, int port);
 
 #endif /* SPOCK_H */
 
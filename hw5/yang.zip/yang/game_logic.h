/**************************************************************
 * game_logic.h
 *
 * Header file for game logic and utility functions for
 * "Rock, Paper, Scissors, Lizard, Spock".
 *
 **************************************************************/

 #ifndef GAME_LOGIC_H
 #define GAME_LOGIC_H
 
 #include "spock.h"
 
 /* Converts a character (R, P, S, L, K) to the corresponding Move enum.
    Returns MOVE_INVALID if the command is invalid. */
 Move charToMove(char c);
 
 /* Returns a short string representation for the given move. */
 const char* moveToString(Move move);
 
 /* Compares two moves:
    Returns  1 if move1 wins, -1 if move2 wins, or 0 if tie.
 */
 int compareMoves(Move move1, Move move2);
 
 /* Prints a fancy ASCII welcome banner for the server. */
 void printWelcomeBanner();
 
 /* Prints usage instructions for command line arguments. */
 void printUsageInstructions();
 
 /* Displays the main menu with possible commands (unused here, but available). */
 void showMainMenu();
 
 /* Displays the current game score in a formatted manner. */
 void showScore(int scoreP1, int scoreP2);
 
 /* Prints the round result including moves and outcome. */
 void printRoundResult(Move m1, Move m2, int result);
 
 #endif /* GAME_LOGIC_H */
 
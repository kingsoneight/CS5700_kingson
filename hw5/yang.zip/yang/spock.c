/**************************************************************
 * spock.c
 *
 * Main entry point for the SPOCK game.
 * Implements both server (-s) and client (-c) modes using TCP sockets.
 *
 * This version supports three players:
 *   - Server acts as Player1.
 *   - Two clients connect as Player2 and Player3.
 *
 * In each round, the server:
 *   1. Reads its own move.
 *   2. Sends a READY message to both clients.
 *   3. Waits for moves from both clients.
 *   4. Compares the three moves pairwise to determine the round winner.
 *   5. Updates and broadcasts the scores.
 *
 * Updated logic:
 *   - After pairwise comparisons, if one player has a higher win count than the others, that player is the unique winner.
 *   - If more than one player share the maximum win count (and it’s higher than the third), they are declared joint winners.
 *   - If all win counts are equal, it is declared a tie.
 *
 * UI feedback has been enhanced with color-coded and structured output.
 *
 **************************************************************/

 #include "spock.h"
 #include "game_logic.h"
 #include <sys/select.h> // For select()
 #include <fcntl.h>      // For fcntl()
 
 /* Forward declarations */
 static void handleServerConnection(int client_fd1, int client_fd2);
 static int sendMessage(int fd, MsgType type, const char* payload);
 static int recvMessage(int fd, MsgType* type, char* buffer, size_t buflen);
 static void broadcastMessage(int client_fds[], int count, MsgType type, const char* payload);
 
 /* runServer: waits for two client connections, then enters 3-player game loop. */
 int runServer(int port) {
     int sockfd;
     struct sockaddr_in server_addr, client_addr;
     socklen_t addr_len = sizeof(client_addr);
 
     /* Create socket */
     if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
         perror("socket() failed");
         return -1;
     }
     memset(&server_addr, 0, sizeof(server_addr));
     server_addr.sin_family      = AF_INET;
     server_addr.sin_addr.s_addr = INADDR_ANY;
     server_addr.sin_port        = htons(port);
 
     int opt = 1;
     setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
 
     if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
         perror("bind() failed");
         close(sockfd);
         return -1;
     }
 
     /* Listen for up to 2 incoming connections */
     if (listen(sockfd, 2) < 0) {
         perror("listen() failed");
         close(sockfd);
         return -1;
     }
 
     printf(ANSI_GREEN "Server listening on port %d...\n" ANSI_RESET, port);
     printf("Waiting for two clients to connect...\n");
 
     int client_fd[2];
     for (int i = 0; i < 2; i++) {
         client_fd[i] = accept(sockfd, (struct sockaddr *)&client_addr, &addr_len);
         if (client_fd[i] < 0) {
             perror("accept() failed");
             close(sockfd);
             return -1;
         }
         printf(ANSI_GREEN "Client %d connected!\n" ANSI_RESET, i + 1);
     }
     printf(ANSI_GREEN "All clients connected! Starting 3-player game...\n\n" ANSI_RESET);
 
     handleServerConnection(client_fd[0], client_fd[1]);
 
     close(client_fd[0]);
     close(client_fd[1]);
     close(sockfd);
     return 0;
 }
 
 /* Helper: broadcast a message to all client sockets */
 static void broadcastMessage(int client_fds[], int count, MsgType type, const char* payload) {
     for (int i = 0; i < count; i++) {
         sendMessage(client_fds[i], type, payload);
     }
 }
 
 /* handleServerConnection: main game loop for three-player game */
 static void handleServerConnection(int client_fd1, int client_fd2) {
     int scoreP1 = 0, scoreP2 = 0, scoreP3 = 0;  // Scores for Player1(Server), Player2, Player3
     int client_fds[2] = { client_fd1, client_fd2 };
 
     while (1) {
         // Prompt server user for command/move
         printf(ANSI_BOLD "Server (Player1) - Enter a command:\n" ANSI_RESET);
         printf("  [R/P/S/L/K] to play a move\n");
         printf("  M: Show Score, T: Reset Score, Q: Quit\n");
         printf("Your choice: ");
         fflush(stdout);
 
         char cmd[BUFFER_SIZE];
         if (!fgets(cmd, BUFFER_SIZE, stdin)) {
             printf(ANSI_RED "Error reading input. Exiting...\n" ANSI_RESET);
             broadcastMessage(client_fds, 2, MSG_QUIT, "Server error");
             break;
         }
         char *newline = strchr(cmd, '\n');
         if (newline) *newline = '\0';
         if (strlen(cmd) < 1) continue;
 
         char c = toupper((unsigned char)cmd[0]);
 
         /* Special commands */
         if (c == 'M') {
             char payload[BUFFER_SIZE];
             snprintf(payload, sizeof(payload), "%d %d %d", scoreP1, scoreP2, scoreP3);
             printf(ANSI_CYAN "Current Score -> " ANSI_RESET "P1: %d | P2: %d | P3: %d\n", scoreP1, scoreP2, scoreP3);
             broadcastMessage(client_fds, 2, MSG_SCORE, payload);
             continue;
         } else if (c == 'T') {
             scoreP1 = scoreP2 = scoreP3 = 0;
             char payload[BUFFER_SIZE];
             snprintf(payload, sizeof(payload), "%d %d %d", scoreP1, scoreP2, scoreP3);
             printf(ANSI_YELLOW "All scores have been reset to 0.\n" ANSI_RESET);
             broadcastMessage(client_fds, 2, MSG_RESET, payload);
             continue;
         } else if (c == 'Q') {
             broadcastMessage(client_fds, 2, MSG_QUIT, "");
             printf(ANSI_RED "Server quitting the game.\n" ANSI_RESET);
             break;
         }
 
         /* Otherwise, treat as move input */
         Move m1 = charToMove(c);
         if (m1 == MOVE_INVALID) {
             printf(ANSI_RED "Invalid command: %c\n" ANSI_RESET, c);
             continue;
         }
 
         // Notify both clients to send their moves
         broadcastMessage(client_fds, 2, MSG_READY, "");
 
         // Wait for moves from both clients
         Move m2 = MOVE_INVALID, m3 = MOVE_INVALID;
         int received = 0;
         while (received < 2) {
             fd_set readfds;
             FD_ZERO(&readfds);
             FD_SET(client_fd1, &readfds);
             FD_SET(client_fd2, &readfds);
             int maxfd = (client_fd1 > client_fd2 ? client_fd1 : client_fd2) + 1;
             int activity = select(maxfd, &readfds, NULL, NULL, NULL);
             if (activity < 0 && errno != EINTR) {
                 perror("select() error");
                 return;
             }
             if (FD_ISSET(client_fd1, &readfds) && m2 == MOVE_INVALID) {
                 MsgType type;
                 char buffer[BUFFER_SIZE];
                 if (recvMessage(client_fd1, &type, buffer, BUFFER_SIZE) <= 0) {
                     printf(ANSI_RED "Client 1 disconnected unexpectedly.\n" ANSI_RESET);
                     return;
                 }
                 if (type == MSG_MOVE) {
                     m2 = charToMove(buffer[0]);
                     if (m2 == MOVE_INVALID) {
                         printf(ANSI_RED "Client 1 sent an invalid move.\n" ANSI_RESET);
                         continue;
                     }
                     received++;
                 } else if (type == MSG_QUIT) {
                     printf(ANSI_RED "Client 1 quit the game.\n" ANSI_RESET);
                     return;
                 }
             }
             if (FD_ISSET(client_fd2, &readfds) && m3 == MOVE_INVALID) {
                 MsgType type;
                 char buffer[BUFFER_SIZE];
                 if (recvMessage(client_fd2, &type, buffer, BUFFER_SIZE) <= 0) {
                     printf(ANSI_RED "Client 2 disconnected unexpectedly.\n" ANSI_RESET);
                     return;
                 }
                 if (type == MSG_MOVE) {
                     m3 = charToMove(buffer[0]);
                     if (m3 == MOVE_INVALID) {
                         printf(ANSI_RED "Client 2 sent an invalid move.\n" ANSI_RESET);
                         continue;
                     }
                     received++;
                 } else if (type == MSG_QUIT) {
                     printf(ANSI_RED "Client 2 quit the game.\n" ANSI_RESET);
                     return;
                 }
             }
         }
 
         // Pairwise comparisons
         int win1 = 0, win2 = 0, win3 = 0;
         int r12 = compareMoves(m1, m2);
         int r13 = compareMoves(m1, m3);
         int r23 = compareMoves(m2, m3);
         if (r12 == 1) win1++; else if (r12 == -1) win2++;
         if (r13 == 1) win1++; else if (r13 == -1) win3++;
         if (r23 == 1) win2++; else if (r23 == -1) win3++;
 
         // Determine maximum win count
         int max_win = win1;
         if (win2 > max_win) max_win = win2;
         if (win3 > max_win) max_win = win3;
         int winnerCount = 0;
         if (win1 == max_win) winnerCount++;
         if (win2 == max_win) winnerCount++;
         if (win3 == max_win) winnerCount++;
 
         char resultText[BUFFER_SIZE];
         memset(resultText, 0, sizeof(resultText));
         if (winnerCount == 0) {
             snprintf(resultText, sizeof(resultText), ANSI_YELLOW "It's a tie!" ANSI_RESET);
         } else if (winnerCount == 1) {
             if (win1 == max_win) {
                 scoreP1++;
                 snprintf(resultText, sizeof(resultText), ANSI_GREEN "Player1 (Server) wins the round!" ANSI_RESET);
             } else if (win2 == max_win) {
                 scoreP2++;
                 snprintf(resultText, sizeof(resultText), ANSI_GREEN "Player2 (Client1) wins the round!" ANSI_RESET);
             } else if (win3 == max_win) {
                 scoreP3++;
                 snprintf(resultText, sizeof(resultText), ANSI_GREEN "Player3 (Client2) wins the round!" ANSI_RESET);
             }
         } else { // More than one winner: joint winners, but here we choose to consider it a tie if not a unique winner.
             snprintf(resultText, sizeof(resultText), ANSI_YELLOW "Round is a tie!" ANSI_RESET);
         }
 
         // Display round result on server with enhanced UI
         printf(ANSI_CYAN "\n========================================\n" ANSI_RESET);
         printf(ANSI_BOLD "          Round Result\n" ANSI_RESET);
         printf(ANSI_CYAN "========================================\n" ANSI_RESET);
         printf("  Player1 (Server) chose %s\n", moveToString(m1));
         printf("  Player2 (Client1) chose %s\n", moveToString(m2));
         printf("  Player3 (Client2) chose %s\n", moveToString(m3));
         printf("  --> %s\n", resultText);
         printf(ANSI_CYAN "----------------------------------------\n" ANSI_RESET);
         printf(ANSI_BOLD "  Current Score:\n" ANSI_RESET);
         printf("  Player1: %d | Player2: %d | Player3: %d\n", scoreP1, scoreP2, scoreP3);
         printf(ANSI_CYAN "========================================\n\n" ANSI_RESET);
 
         // Broadcast round result and scores to both clients
         char payload[BUFFER_SIZE];
         // Payload format: "m1 m2 m3 scoreP1 scoreP2 scoreP3 resultText"
         snprintf(payload, sizeof(payload), "%d %d %d %d %d %d %s",
                  m1, m2, m3, scoreP1, scoreP2, scoreP3, resultText);
         broadcastMessage(client_fds, 2, MSG_RESULT, payload);
     }
 }
 
 /*
  * runClient:
  * 1. Creates a TCP socket and connects to the server.
  * 2. Listens for server messages and handles user input.
  *    Supports special commands and valid move input.
  */
 int runClient(const char *server_ip, int port) {
     int sockfd;
     struct sockaddr_in serv_addr;
     if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
         perror("socket() failed");
         return -1;
     }
     memset(&serv_addr, 0, sizeof(serv_addr));
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_port   = htons(port);
     if (inet_pton(AF_INET, server_ip, &serv_addr.sin_addr) <= 0) {
         perror("inet_pton() failed");
         close(sockfd);
         return -1;
     }
     if (connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
         perror("connect() failed");
         close(sockfd);
         return -1;
     }
  
     /* Display a blue box with game background, rules and instructions */
     printf(ANSI_BLUE "┌────────────────────────────────────────────────────────────┐\n" ANSI_RESET);
     printf(ANSI_BLUE "│" ANSI_RESET ANSI_BOLD "       Welcome to Rock, Paper, Scissors,                " ANSI_RESET ANSI_BLUE "│\n" ANSI_RESET);
     printf(ANSI_BLUE "│" ANSI_RESET ANSI_BOLD "       Lizard, Spock (3-Player Edition)                 " ANSI_RESET ANSI_BLUE "│\n" ANSI_RESET);
     printf(ANSI_BLUE "├────────────────────────────────────────────────────────────┤\n" ANSI_RESET);
     printf(ANSI_BLUE "│" ANSI_RESET ANSI_YELLOW "Game Rules:" ANSI_RESET "                                     " ANSI_BLUE "│\n" ANSI_RESET);
     printf(ANSI_BLUE "│" ANSI_RESET "  - 3 players each choose one of: R/P/S/L/K.               " ANSI_BLUE "│\n" ANSI_RESET);
     printf(ANSI_BLUE "│" ANSI_RESET "  - Pairwise comparisons decide the round winner.           " ANSI_BLUE "│\n" ANSI_RESET);
     printf(ANSI_BLUE "│" ANSI_RESET "  - Special commands: M (score), T (reset), Q (quit).         " ANSI_BLUE "│\n" ANSI_RESET);
     printf(ANSI_BLUE "├────────────────────────────────────────────────────────────┤\n" ANSI_RESET);
     printf(ANSI_BLUE "│" ANSI_RESET ANSI_YELLOW "How to Play:" ANSI_RESET "                                  " ANSI_BLUE "│\n" ANSI_RESET);
     printf(ANSI_BLUE "│" ANSI_RESET "  1) Wait for the server (Player1) to start a round.         " ANSI_BLUE "│\n" ANSI_RESET);
     printf(ANSI_BLUE "│" ANSI_RESET "  2) When prompted, enter your move (R/P/S/L/K) or a command.  " ANSI_BLUE "│\n" ANSI_RESET);
     printf(ANSI_BLUE "└────────────────────────────────────────────────────────────┘\n" ANSI_RESET);
     printf("\n");
 
     printf(ANSI_GREEN "Connected to server %s:%d!\n" ANSI_RESET, server_ip, port);
 
     int waitingForMove = 0;
     char buffer[BUFFER_SIZE];
 
     while (1) {
         fd_set readfds;
         FD_ZERO(&readfds);
         FD_SET(sockfd, &readfds);
         FD_SET(STDIN_FILENO, &readfds);
         int maxfd = (sockfd > STDIN_FILENO ? sockfd : STDIN_FILENO) + 1;
 
         int activity = select(maxfd, &readfds, NULL, NULL, NULL);
         if (activity < 0 && errno != EINTR) {
             perror("select() error");
             break;
         }
 
         if (FD_ISSET(sockfd, &readfds)) {
             MsgType type;
             int n = recvMessage(sockfd, &type, buffer, BUFFER_SIZE);
             if (n <= 0) {
                 printf(ANSI_RED "Server disconnected. Exiting...\n" ANSI_RESET);
                 break;
             }
             switch (type) {
                 case MSG_READY:
                     waitingForMove = 1;
                     printf(ANSI_BOLD "Server is ready. Enter your move (R/P/S/L/K): " ANSI_RESET);
                     fflush(stdout);
                     break;
                 case MSG_RESULT: {
                     // Payload format: "m1 m2 m3 scoreP1 scoreP2 scoreP3 resultText"
                     int m1, m2, m3, s1, s2, s3;
                     char resultText[BUFFER_SIZE] = "";
                     sscanf(buffer, "%d %d %d %d %d %d %[^\n]",
                            &m1, &m2, &m3, &s1, &s2, &s3, resultText);
                     printf(ANSI_CYAN "\n========= Round Result =========\n" ANSI_RESET);
                     printf("  Player1 (Server) chose %s\n", moveToString((Move)m1));
                     printf("  Player2 (Client1) chose %s\n", moveToString((Move)m2));
                     printf("  Player3 (Client2) chose %s\n", moveToString((Move)m3));
                     printf("  --> %s\n", resultText);
                     printf("Score Update: Player1: %d | Player2: %d | Player3: %d\n", s1, s2, s3);
                     printf(ANSI_CYAN "================================\n\n" ANSI_RESET);
                     break;
                 }
                 case MSG_SCORE: {
                     int s1, s2, s3;
                     if (sscanf(buffer, "%d %d %d", &s1, &s2, &s3) == 3)
                         printf(ANSI_YELLOW "Current Score -> " ANSI_RESET "P1: %d | P2: %d | P3: %d\n", s1, s2, s3);
                     else
                         printf(ANSI_YELLOW "Server requested to show score, but no data received.\n" ANSI_RESET);
                     break;
                 }
                 case MSG_RESET: {
                     int s1, s2, s3;
                     if (sscanf(buffer, "%d %d %d", &s1, &s2, &s3) == 3) {
                         printf(ANSI_YELLOW "Server has reset the scores.\n" ANSI_RESET);
                         printf("Current Score -> P1: %d | P2: %d | P3: %d\n", s1, s2, s3);
                     } else {
                         printf(ANSI_YELLOW "Server reset the score, but no data received.\n" ANSI_RESET);
                     }
                     break;
                 }
                 case MSG_QUIT:
                     printf(ANSI_RED "Server quit the game. Disconnecting...\n" ANSI_RESET);
                     goto client_cleanup;
                 default:
                     break;
             }
         }
 
         if (FD_ISSET(STDIN_FILENO, &readfds)) {
             char cmd[BUFFER_SIZE];
             if (fgets(cmd, BUFFER_SIZE, stdin) != NULL) {
                 char *nl = strchr(cmd, '\n');
                 if (nl) *nl = '\0';
                 if (strlen(cmd) == 0) continue;
                 char c = toupper((unsigned char)cmd[0]);
                 if (waitingForMove) {
                     Move m = charToMove(c);
                     if (m == MOVE_INVALID) {
                         printf(ANSI_RED "Invalid move. Please enter R, P, S, L, or K.\n" ANSI_RESET);
                     } else {
                         char sendBuf[2] = { c, '\0' };
                         sendMessage(sockfd, MSG_MOVE, sendBuf);
                         waitingForMove = 0;
                     }
                 } else {
                     if (c == 'M') {
                         sendMessage(sockfd, MSG_SCORE, "");
                     } else if (c == 'T') {
                         sendMessage(sockfd, MSG_RESET, "");
                     } else if (c == 'Q') {
                         sendMessage(sockfd, MSG_QUIT, "");
                         printf(ANSI_RED "Quitting the game...\n" ANSI_RESET);
                         goto client_cleanup;
                     } else {
                         printf(ANSI_RED "You can only input a move when prompted by the server.\n" ANSI_RESET);
                     }
                 }
             }
         }
     }
 
 client_cleanup:
     close(sockfd);
     return 0;
 }
 
 /*
  * sendMessage:
  * Sends a message over the given socket.
  * Message format: [1 byte: MsgType][payload string...]
  */
 static int sendMessage(int fd, MsgType type, const char* payload) {
     char buffer[BUFFER_SIZE];
     memset(buffer, 0, BUFFER_SIZE);
     buffer[0] = (char)type;
     if (payload) {
         strncpy(&buffer[1], payload, BUFFER_SIZE - 2);
     }
     ssize_t n = send(fd, buffer, strlen(&buffer[1]) + 2, 0);
     return (n > 0) ? (int)n : -1;
 }
 
 /*
  * recvMessage:
  * Receives a message from the given socket.
  * Decodes the first byte as MsgType and the rest as payload.
  */
 static int recvMessage(int fd, MsgType* type, char* buffer, size_t buflen) {
     char tmp[BUFFER_SIZE];
     memset(tmp, 0, BUFFER_SIZE);
     ssize_t n = recv(fd, tmp, BUFFER_SIZE, 0);
     if (n <= 0) return (int)n;
     *type = (MsgType)tmp[0];
     if (n > 1 && buffer && buflen > 0) {
         strncpy(buffer, &tmp[1], buflen - 1);
         buffer[buflen - 1] = '\0';
     } else {
         if (buffer && buflen > 0) buffer[0] = '\0';
     }
     return (int)n;
 }
 
 /*
  * main:
  * Parses command line arguments to run as server or client.
  */
 int main(int argc, char *argv[]) {
     if (argc < 2) {
         printUsageInstructions();
         return 0;
     }
     if (strcmp(argv[1], "-s") == 0) {
         int port = DEFAULT_PORT;
         if (argc >= 3) {
             port = atoi(argv[2]);
             if (port <= 0) port = DEFAULT_PORT;
         }
         return runServer(port);
     } else if (strcmp(argv[1], "-c") == 0) {
         if (argc < 3) {
             printUsageInstructions();
             return -1;
         }
         const char* server_ip = argv[2];
         int port = DEFAULT_PORT;
         if (argc >= 4) {
             port = atoi(argv[3]);
             if (port <= 0) port = DEFAULT_PORT;
         }
         return runClient(server_ip, port);
     } else {
         printUsageInstructions();
         return 0;
     }
 }
 
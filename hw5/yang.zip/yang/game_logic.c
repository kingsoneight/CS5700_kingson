/**************************************************************
 * game_logic.c
 *
 * Implements core game logic and UI utility functions for
 * "Rock, Paper, Scissors, Lizard, Spock".
 *
 **************************************************************/

 #include "game_logic.h"

 /* Convert a single character to the corresponding Move enum */
 Move charToMove(char c) {
     c = toupper((unsigned char)c);
     switch(c) {
         case 'R': return MOVE_ROCK;
         case 'P': return MOVE_PAPER;
         case 'S': return MOVE_SCISSORS;
         case 'L': return MOVE_LIZARD;
         case 'K': return MOVE_SPOCK;  /* 'K' stands for SpocK */
         default:  return MOVE_INVALID;
     }
 }
 
 /* Return a short string representation for the given move */
 const char* moveToString(Move move) {
     switch(move) {
         case MOVE_ROCK:     return "Rock";
         case MOVE_PAPER:    return "Paper";
         case MOVE_SCISSORS: return "Scissors";
         case MOVE_LIZARD:   return "Lizard";
         case MOVE_SPOCK:    return "Spock";
         default:            return "Invalid";
     }
 }
 
 /* Compare two moves:
    Returns 1 if move1 wins, -1 if move2 wins, or 0 if tie.
 */
 int compareMoves(Move m1, Move m2) {
     if (m1 == m2) return 0;
     switch(m1) {
         case MOVE_ROCK:
             if (m2 == MOVE_SCISSORS || m2 == MOVE_LIZARD)
                 return 1;
             else
                 return -1;
         case MOVE_PAPER:
             if (m2 == MOVE_ROCK || m2 == MOVE_SPOCK)
                 return 1;
             else
                 return -1;
         case MOVE_SCISSORS:
             if (m2 == MOVE_PAPER || m2 == MOVE_LIZARD)
                 return 1;
             else
                 return -1;
         case MOVE_LIZARD:
             if (m2 == MOVE_SPOCK || m2 == MOVE_PAPER)
                 return 1;
             else
                 return -1;
         case MOVE_SPOCK:
             if (m2 == MOVE_SCISSORS || m2 == MOVE_ROCK)
                 return 1;
             else
                 return -1;
         default:
             return 0;
     }
 }
 
 /* Print a fancy ASCII welcome banner (used for server side in main). */
 void printWelcomeBanner() {
     printf(ANSI_CYAN "==============================================\n" ANSI_RESET);
     printf(ANSI_BOLD   "  Welcome to Rock, Paper, Scissors, Lizard, Spock!\n" ANSI_RESET);
     printf(ANSI_CYAN "==============================================\n" ANSI_RESET);
     printf("\n");
 }
 
 /* Print usage instructions for command line arguments */
 void printUsageInstructions() {
     printf(ANSI_YELLOW "Usage:\n" ANSI_RESET);
     printf("  spock -s [port]               Run as server on specified port (default 5000 if omitted)\n");
     printf("  spock -c <server_ip> [port]    Run as client connecting to <server_ip> on specified port (default 5000)\n");
     printf("\nExample:\n");
     printf("  spock -s 6000            (Start server on port 6000)\n");
     printf("  spock -c 127.0.0.1 6000  (Connect client to local server on port 6000)\n\n");
 }
 
 /* Display the main menu with possible commands (unused by default) */
 void showMainMenu() {
     printf(ANSI_BOLD "Command Options:\n" ANSI_RESET);
     printf("  R = Rock, P = Paper, S = Scissors, L = Lizard, K = Spock\n");
     printf("  M = Show Score, T = Reset Score, Q = Quit\n");
 }
 
 /* Display the current game score in a formatted manner */
 void showScore(int scoreP1, int scoreP2) {
     printf(ANSI_GREEN "\n-------------------------\n" ANSI_RESET);
     printf(ANSI_BOLD   "   Score: Player1 [%d] | Player2 [%d]\n" ANSI_RESET, scoreP1, scoreP2);
     printf(ANSI_GREEN "-------------------------\n\n" ANSI_RESET);
 }
 
 /* Print the round result including moves and outcome */
 void printRoundResult(Move m1, Move m2, int result) {
     printf("\nRound Result:\n");
     printf("  Player1 chose %s\n", moveToString(m1));
     printf("  Player2 chose %s\n", moveToString(m2));
     if (result == 0)
         printf(ANSI_YELLOW "  --> It's a Tie!\n" ANSI_RESET);
     else if (result > 0)
         printf(ANSI_GREEN  "  --> Player1 Wins this round!\n" ANSI_RESET);
     else
         printf(ANSI_RED    "  --> Player2 Wins this round!\n" ANSI_RESET);
     printf("\n");
 }
 